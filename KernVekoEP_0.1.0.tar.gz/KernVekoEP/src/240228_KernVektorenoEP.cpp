#include <Rcpp.h>
#include <math.h>
using namespace Rcpp;

// Minimum-Funktion

double minC(double x, double y) {
  if(x<=y){
    return x;
  }
  else
    return y; 
}


// Maximum-Funktion

double maxC(double x, double y) {
  if(x>=y){
    return x;
  }
  else
    return y;
}



// Kern * Kern

// [[Rcpp::export]]
NumericVector KernDuo(double b, double T, double Anf, double End, int l, int h) {
  int f=0.5*(h-(h*h))+l*h;
  int s=0;
  double mini;
  double maxi;
  double Integral1;
  double Integral2;
  double Integral3;
  double Integral4;
  double Integral5;
  double A;
  double B;
  double C;
  double D;
  double E=1/(b*b*b*b);
  
  NumericVector duo(f+1);
  
  for(double i = Anf; i <= End; i++) {
    maxi=i/T-b;
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      mini=j/T+b;
      
      if(mini>maxi){
        Integral1=mini-maxi;
        
        Integral2=((mini*mini)-(maxi*maxi))/2.0;
        
        Integral3=((mini*mini*mini)-(maxi*maxi*maxi))/3.0;
        
        Integral4=((mini*mini*mini*mini)-(maxi*maxi*maxi*maxi))/4.0;
        
        Integral5=((mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi))/5.0;
        
        A=1-(((i*i)+(j*j))/(b*T*b*T))+((i*j*i*j)/(b*T*b*T*b*T*b*T));
        
        B=2*(((i+j)/((b*b)*T))-((i*(j*j)+((i*i)*j))/((b*b*b*b)*(T*T*T))));
        
        C=(((i*i)+(4*i*j)+(j*j))/((b*b*b*b)*(T*T)))-(2/((b*b)));
        
        D=2*(i+j)/((b*b*b*b)*T);
        
        duo[s]=(9.0/16)*((A*Integral1)+(B*Integral2)+(C*Integral3)-(D*Integral4)+(E*Integral5));
      } else {
        duo[s]=0;
      }
      s++;
    }
  }
  return duo;
}



// Kern * Kern * Kern

// [[Rcpp::export]]
NumericVector KernTrio(double b, double T, double Anf, double End, int l, int h) {
  int f=-(1.0/3)*(h*h*h)+0.5*l*(h*h)+((1.0/3)+(0.5*l))*h;
  int s=0;
  double Integral6;
  double Integral7;
  double mini;
  double maxi;
  double Integral12;
  double Integral22;
  double Integral32;
  double Integral42;
  double Integral52;
  double A;
  double B;
  double C;
  double D;
  double E=1/(b*b*b*b);
  
  NumericVector trio(f+1);
  
  for(double i = Anf; i <= End; i++) {
    maxi=i/T-b;
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      A=1-(((i*i)+(j*j))/(b*T*b*T))+((i*j*i*j)/(b*T*b*T*b*T*b*T));
      
      B=2*(((i+j)/((b*b)*T))-((i*(j*j)+((i*i)*j))/(b*b*b*b*T*T*T)));
      
      C=(((i*i)+(4*i*j)+(j*j))/(b*b*b*b*T*T))-(2/(b*b));
      
      D=2*(i+j)/((b*b*b*b)*T);
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        mini=k/T+b;
        
        if(mini>maxi){
          Integral12=mini-maxi;
          
          Integral22=((mini*mini)-(maxi*maxi))/2.0;
          
          Integral32=((mini*mini*mini)-(maxi*maxi*maxi))/3.0;
          
          Integral42=((mini*mini*mini*mini)-(maxi*maxi*maxi*maxi))/4.0;
          
          Integral52=((mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi))/5.0;
          
          Integral6=((mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi))/6.0;
          
          Integral7=((mini*mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi*maxi))/7.0;
          
          trio[s]=(27.0/64)*((1-((k*k)/(b*T*b*T)))*((A*Integral12)+(B*Integral22)+(C*Integral32)-(D*Integral42)+(E*Integral52))
                               +(2*k/(b*b*T)*((A*Integral22)+(B*Integral32)+(C*Integral42)-(D*Integral52)+(E*Integral6)))
                               -(1/(b*b))*((A*Integral32)+(B*Integral42)+(C*Integral52)-(D*Integral6)+(E*Integral7)));
        } else {
          trio[s]=0;
        }
        s++;
      }
    }
  }
  return trio;
}



// Kern * Kern * Kern * Kern

// [[Rcpp::export]]
NumericVector KernQuartett(double b, double T, double Anf, double End, int l, int h) {
  int f=0.25*(0.5*((h*h)-(h*h*h*h))+h-(h*h*h))+(l/6.0)*((h*h*h)+(3*(h*h))+(2*h));
  int s=0;
  double mini;
  double maxi;
  double Integral13;
  double Integral23;
  double Integral33;
  double Integral43;
  double Integral53;
  double Integral63;
  double Integral73;
  double Integral83;
  double Integral93;
  double A;
  double B;
  double C;
  double D;
  double E=1/(b*b*b*b);
  
  NumericVector quartett(f+1);
  
  for(double i = Anf; i <= End; i++) {
    maxi=i/T-b;
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      A=1-(((i*i)+(j*j))/(b*T*b*T))+((i*j*i*j)/(b*T*b*T*b*T*b*T));
      
      B=2*(((i+j)/((b*b)*T))-((i*(j*j)+((i*i)*j))/(b*b*b*b*T*T*T)));
      
      C=(((i*i)+(4*i*j)+(j*j))/(b*b*b*b*T*T))-(2/(b*b));
      
      D=2*(i+j)/(b*b*b*b*T);
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        for (double m = maxC(i-h+1,Anf); m <= k; m++) {
          mini=m/T+b;
          
          if(mini>maxi){
            Integral13=mini-maxi;
            
            Integral23=((mini*mini)-(maxi*maxi))/2.0;
            
            Integral33=((mini*mini*mini)-(maxi*maxi*maxi))/3.0;
            
            Integral43=((mini*mini*mini*mini)-(maxi*maxi*maxi*maxi))/4.0;
            
            Integral53=((mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi))/5.0;
            
            Integral63=((mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi))/6.0;
            
            Integral73=((mini*mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi*maxi))/7.0;
            
            Integral83=((mini*mini*mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi*maxi*maxi))/8.0;
            
            Integral93=((mini*mini*mini*mini*mini*mini*mini*mini*mini)-(maxi*maxi*maxi*maxi*maxi*maxi*maxi*maxi*maxi))/9.0;
            
            quartett[s]=(81.0/256)*( 
              (1-((m*m)/(b*T*b*T)))*((1-((k*k)/(b*T*b*T)))*((A*Integral13)+(B*Integral23)+(C*Integral33)-(D*Integral43)+(E*Integral53))
                                       +(2*k/((b*b)*T)*((A*Integral23)+(B*Integral33)+(C*Integral43)-(D*Integral53)+(E*Integral63)))
                                       -(1/(b*b))*((A*Integral33)+(B*Integral43)+(C*Integral53)-(D*Integral63)+(E*Integral73)))
                                       +((2*m/(b*b*T))*((1-((k*k)/(b*T*b*T)))*((A*Integral23)+(B*Integral33)+(C*Integral43)-(D*Integral53)+(E*Integral63))
                                       +(2*k/(b*b*T)*((A*Integral33)+(B*Integral43)+(C*Integral53)-(D*Integral63)+(E*Integral73)))
                                       -(1/(b*b))*((A*Integral43)+(B*Integral53)+(C*Integral63)-(D*Integral73)+(E*Integral83))))
                                       -(1/(b*b))*((1-((k*k)/(b*T*b*T)))*((A*Integral33)+(B*Integral43)+(C*Integral53)-(D*Integral63)+(E*Integral73))
                                       +(2*k/(b*b*T)*((A*Integral43)+(B*Integral53)+(C*Integral63)-(D*Integral73)+(E*Integral83)))
                                       -(1/(b*b))*((A*Integral53)+(B*Integral63)+(C*Integral73)-(D*Integral83)+(E*Integral93)))
            );
          } else {
            quartett[s]=0;
          }
          s++;
        }
      }
    }
  }
  return quartett;
}



// Exponentialfunktion

double efC(double x, double y) {
  double out = exp(-(pow(x-y, 2.0))/4);
  return out;
}



// Kern * Kern * Exponentialfunktion Isum1 Isum1_stern

// [[Rcpp::export]]
double KVek(NumericVector KK, NumericVector Y, NumericVector Z, double Anf, double End, int h) {
  int s=0;
  double t=0;

  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j < i; j++) {
      
      t+=(KK[s]*efC(Z[i],Z[j])*efC(Y[i],Y[j])*2); 
      s++;
    }
    t+=(KK[s]); 
    s++;
  }
  return t;
}



// Kern * Kern * Kern * Exponentialfunktion Isum2 Isum2_stern

// [[Rcpp::export]]
double KVek2(NumericVector KKK, NumericVector Y, NumericVector Z, double Anf, double End, int h) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      Yij=efC(Y[i],Y[j]);
      Zij=efC(Z[i],Z[j]);
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        Yik=efC(Y[i],Y[k]);
        Zik=efC(Z[i],Z[k]);
        Yjk=efC(Y[j],Y[k]);
        Zjk=efC(Z[j],Z[k]);
        
        if ((i==j) && (j==k)){
          t+=(KKK[s]);
        } else if((i==j) && (j!=k)) {
          t+=(KKK[s]*(Zik+(Zik*Yik)+Yik));
        } else if((i!=j) && (j==k)) {
          t+=(KKK[s]*((Zij*Yij)+Zij+Yij)); 
        } else {
          t+=(KKK[s]*((Zik*Yij)+(Zik*Yjk)+(Zij*Yjk)+(Zij*Yik)+(Zjk*Yik)+(Zjk*Yij)));
        }
        s++;
      }
    }
  }
  return t;
}



// Kern * Kern * Kern * Kern * Exponentialfunktion Isum3 Isum3_stern

// [[Rcpp::export]]
double KVek3(NumericVector KKKK, NumericVector Y, NumericVector Z, double Anf, double End, int h) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  double Yim;
  double Zim;
  double Yjm;
  double Zjm;
  double Ykm;
  double Zkm;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      Yij=efC(Y[i],Y[j]);
      Zij=efC(Z[i],Z[j]);
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        Yik=efC(Y[i],Y[k]);
        Zik=efC(Z[i],Z[k]);
        Yjk=efC(Y[j],Y[k]);
        Zjk=efC(Z[j],Z[k]);
        
        for(double m = maxC(i-h+1,Anf); m <= k; m++) {
          Yim=efC(Y[i],Y[m]);
          Zim=efC(Z[i],Z[m]);
          Yjm=efC(Y[j],Y[m]);
          Zjm=efC(Z[j],Z[m]);
          Ykm=efC(Y[k],Y[m]);
          Zkm=efC(Z[k],Z[m]);
          
          if ((i==j) && (j==k) && (k==m)){
            t+=(KKKK[s]);
          } else if ((i==j) && (j==k) && (k!=m)) {
            t+=(KKKK[s]*2*(Zim+Yim)); 
          } else if ((i!=j) && (j==k) && (k==m)) {
            t+=(KKKK[s]*2*(Yim+Zim)); 
          } else if ((i==j) && (j!=k) && (k!=m)) {
            t+=(KKKK[s]*((4*((Zim*Yik)+(Zik*Yim)))+(2*(Ykm+Zkm)))); 
          } else if ((i!=j) && (j!=k) && (k==m)) {
            t+=(KKKK[s]*((4*((Zjm*Yim)+(Zim*Yjm)))+(2*(Zij+Yij))));
          } else if ((i!=j) && (j==k) && (k!=m)) {
            t+=(KKKK[s]*((4*((Zjm*Yij)+(Zij*Yjm)))+(2*(Yim+Zim))));
          } else if ((i==j) && (j!=k) && (k==m)) {
            t+=(KKKK[s]*((4*Zim*Yim)+2)); 
          } else {
            t+=(KKKK[s]*4*((Zjm*Yik)+(Zik*Yjm)+(Zij*Ykm)+(Zkm*Yij)+(Zjk*Yim)+(Zim*Yjk)));
          }
          s++;
        }
      }
    }
  }
  return t;
}



// Kern * Kern * Exponentialfunktion Isum1_sternMix

// [[Rcpp::export]]
double KVekBSM(NumericVector KK, NumericVector Y, NumericVector Ystern, NumericVector Z, NumericVector Zstern, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j < i; j++) {
      
      for(int r = -F; r <= F; r++) {
        
        t+=(KK[s]*(efC(Zstern[j],Z[i+r])*efC(Ystern[j],Y[i+r])
					+efC(Zstern[i],Z[j+r])*efC(Ystern[i],Y[j+r])));
      }
      s++;
    }
    for(int r = -F; r <= F; r++) {
      
      t+=(KK[s]*(efC(Zstern[i],Z[i+r])*efC(Ystern[i],Y[i+r])));
    }
    s++;
  }
  return t;
}



// Kern * Kern * Kern * Exponentialfunktion Isum2_sternMix

// [[Rcpp::export]]
double KVekBSM2a(NumericVector KKK, NumericVector Y, NumericVector Ystern, NumericVector Z, NumericVector Zstern, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  double Yji;
  double Zji;
  double Yki;
  double Zki;
  double Ykj;
  double Zkj;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      Yij=0;
      Yji=0;
      
      Zij=0;
      Zji=0;
      
      for(int r1 = -F; r1 <= F; r1++) {
        
        Yij+=efC(Ystern[i],Y[j+r1]);
        Yji+=efC(Ystern[j],Y[i+r1]);
        
        Zij+=efC(Zstern[i],Z[j+r1]);
        Zji+=efC(Zstern[j],Z[i+r1]);
      }
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        Yik=0;
        Yki=0;
        
        Zik=0;
        Zki=0;
        
        Ykj=0;
        Yjk=0;
        
        Zkj=0;
        Zjk=0;

        if ((i==j) && (j==k)){
          
          t+=(KKK[s]*Zij*Yij);
          
        } else if((i==j) && (j!=k)) {
          
          for(int r1 = -F; r1 <= F; r1++) {
            
            Yik+=efC(Ystern[i],Y[k+r1]);
            Yki+=efC(Ystern[k],Y[i+r1]);
            
            Zik+=efC(Zstern[i],Z[k+r1]);
            Zki+=efC(Zstern[k],Z[i+r1]);
          }
          
          t+=(KKK[s]*((Zij*Yik)+(Zik*Yij)+(Zki*Yki)));
        } else if((i!=j) && (j==k)) {
          
          for(int r1 = -F; r1 <= F; r1++) {
            
            Yjk+=efC(Ystern[j],Y[k+r1]);
            
            Zjk+=efC(Zstern[j],Z[k+r1]);
          }
          
          t+=(KKK[s]*((Zij*Yij)+(Zji*Yjk)+(Zjk*Yji)));
        } else {
          
          for(int r1 = -F; r1 <= F; r1++) {
            
            Yik+=efC(Ystern[i],Y[k+r1]);
            Yki+=efC(Ystern[k],Y[i+r1]);
            
            Zik+=efC(Zstern[i],Z[k+r1]);
            Zki+=efC(Zstern[k],Z[i+r1]);
            
            Yjk+=efC(Ystern[j],Y[k+r1]);
            Ykj+=efC(Ystern[k],Y[j+r1]);
            
            Zjk+=efC(Zstern[j],Z[k+r1]);
            Zkj+=efC(Zstern[k],Z[j+r1]);
          }
          
          t+=(KKK[s]*((Zik*Yij)+(Zki*Ykj)+(Zji*Yjk)+(Zij*Yik)+(Zkj*Yki)+(Zjk*Yji)));
        }
        s++;
      }
    }
  }
  return t;
}



// Kern * Kern * Kern * Exponentialfunktion Isum3_sternMix

// [[Rcpp::export]]
double KVekBSM2b(NumericVector KKK, NumericVector Y, NumericVector Ystern, NumericVector Z, NumericVector Zstern, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  double x=0;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        x=0;
        if ((i==j) && (j==k)){
          for(int r = -F; r <= F; r++) {
            x+=(efC(Zstern[k],Z[i+r])*efC(Ystern[j],Y[i+r]));
          }
          
          t+=(KKK[s]*x);
        } else if((i==j) && (j!=k)) {
          for(int r = -F; r <= F; r++) {
            
            x+=(efC(Zstern[k],Z[i+r])*efC(Ystern[j],Y[i+r])
                  +efC(Zstern[i],Z[k+r])*efC(Ystern[j],Y[k+r])
                  +efC(Zstern[j],Z[i+r])*efC(Ystern[k],Y[i+r]));
          }
                
          t+=(KKK[s]*x);
        } else if((i!=j) && (j==k)) {
          for(int r = -F; r <= F; r++) {
            
            x+=(efC(Zstern[i],Z[j+r])*efC(Ystern[k],Y[j+r])
                  +efC(Zstern[j],Z[i+r])*efC(Ystern[k],Y[i+r])
                  +efC(Zstern[k],Z[j+r])*efC(Ystern[i],Y[j+r]));
          }
          t+=(KKK[s]*x);
        } else {
          for(int r = -F; r <= F; r++) {
            
            x+=(efC(Zstern[k],Z[i+r])*efC(Ystern[j],Y[i+r])
                  +efC(Zstern[i],Z[k+r])*efC(Ystern[j],Y[k+r])
                  +efC(Zstern[i],Z[j+r])*efC(Ystern[k],Y[j+r])
                  +efC(Zstern[j],Z[i+r])*efC(Ystern[k],Y[i+r])
                  +efC(Zstern[j],Z[k+r])*efC(Ystern[i],Y[k+r])
                  +efC(Zstern[k],Z[j+r])*efC(Ystern[i],Y[j+r]));
          }
          t+=(KKK[s]*x);
        }
        s++;
      }
    }
  }
  return t;
}    




// Kern * Kern * Kern * Kern * ExponentialfunktionIsum4_sternMix

// [[Rcpp::export]]
double KVekBSM3(NumericVector KKKK, NumericVector Y, NumericVector Ystern, NumericVector Z, NumericVector Zstern, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yji;
  double Zji;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  double Yki;
  double Zki;
  double Ykj;
  double Zkj;
  double Yim;
  double Zim;
  double Yjm;
  double Zjm;
  double Ykm;
  double Zkm;
  double Ymi;
  double Zmi;
  double Ymj;
  double Zmj;
  double Ymk;
  double Zmk;
  
  for(double i = Anf; i <= End; i++) {

    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      Yij=0;
      Zij=0;
      Yji=0;
      Zji=0;

      for(int r = -F; r <= F; r++) {
          
        Yij+=efC(Ystern[i],Y[j+r]);
        Zij+=efC(Zstern[i],Z[j+r]);
        Yji+=efC(Ystern[j],Y[i+r]);
        Zji+=efC(Zstern[j],Z[i+r]);
      }
        
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        Yik=0;
        Zik=0;
        Yjk=0;
        Zjk=0;
        Yki=0;
        Zki=0;
        Ykj=0;
        Zkj=0;
        
        for(int r = -F; r <= F; r++) {
          
          Yik+=efC(Ystern[i],Y[k+r]);
          Zik+=efC(Zstern[i],Z[k+r]);
          Yki+=efC(Ystern[k],Y[i+r]);
          Zki+=efC(Zstern[k],Z[i+r]);
          
          Yjk+=efC(Ystern[j],Y[k+r]);
          Zjk+=efC(Zstern[j],Z[k+r]);
          Ykj+=efC(Ystern[k],Y[j+r]);
          Zkj+=efC(Zstern[k],Z[j+r]);
        }
        for (double m = maxC(i-h+1,Anf); m <= k; m++) {
          
          Yim=0;
          Zim=0;
          Yjm=0;
          Zjm=0;
          Ykm=0;
          Zkm=0;
          Ymi=0;
          Zmi=0;
          Ymj=0;
          Zmj=0;
          Ymk=0;
          Zmk=0;

          if ((i==j) && (j==k) && (k==m)){
            t+=(KKKK[s]*Yij*Yij); 
          } else if ((i==j) && (j==k) && (k!=m)) {
            
            for(int r = -F; r <= F; r++) {
              
              Yim+=efC(Ystern[i],Y[m+r]);
              Zim+=efC(Zstern[i],Z[m+r]);
              Ymi+=efC(Ystern[m],Y[i+r]);
              Zmi+=efC(Zstern[m],Z[i+r]);
              
            }
            
            t+=(KKKK[s]*((Zim+Zmi)*Yij+Zij*(Yim+Ymi))); 
          } else if ((i!=j) && (j==k) && (k==m)) {
            
            t+=(KKKK[s]*(Zjk*(Yij+Yji)+(Zij+Zji)*Yjk)); 
          } else if ((i==j) && (j!=k) && (k!=m)) {
            
            for(int r = -F; r <= F; r++) {
              
              Yim+=efC(Ystern[i],Y[m+r]);
              Zim+=efC(Zstern[i],Z[m+r]);
              Ymi+=efC(Ystern[m],Y[i+r]);
              Zmi+=efC(Zstern[m],Z[i+r]);
              
              Ykm+=efC(Ystern[k],Y[m+r]);
              Zkm+=efC(Zstern[k],Z[m+r]);
              Ymk+=efC(Ystern[m],Y[k+r]);
              Zmk+=efC(Zstern[m],Z[k+r]);
            }
            
            t+=(KKKK[s]*((Zim+Zmi)*(Yik+Yki)+(Zik+Zki)*(Yim+Ymi)+Zij*(Ykm+Ymk)+(Zmk+Zkm)*Yij)); 
          } else if ((i!=j) && (j!=k) && (k==m)) {
            
            for(int r = -F; r <= F; r++) {
              
              Ykm+=efC(Ystern[k],Y[m+r]);
              Zkm+=efC(Zstern[k],Z[m+r]);
            }

            t+=(KKKK[s]*((Zjk+Zkj)*(Yik+Yki)+(Zik+Zki)*(Yjk+Ykj)+(Zij+Zji)*Ykm+Zkm*(Yij+Yji)));
          } else if ((i!=j) && (j==k) && (k!=m)) {
            
            for(int r = -F; r <= F; r++) {
              
              Yim+=efC(Ystern[i],Y[m+r]);
              Zim+=efC(Zstern[i],Z[m+r]);
              Ymi+=efC(Ystern[m],Y[i+r]);
              Zmi+=efC(Zstern[m],Z[i+r]);
              
              Yjm+=efC(Ystern[j],Y[m+r]);
              Zjm+=efC(Zstern[j],Z[m+r]);
              Ymj+=efC(Ystern[m],Y[j+r]);
              Zmj+=efC(Zstern[m],Z[j+r]);

            }
            
            t+=(KKKK[s]*((Zjm+Zmj)*(Yij+Yji)+(Zij+Zji)*(Yjm+Ymj)+Zjk*(Yim+Ymi)+(Zim+Zmi)*Yjk));
          } else if ((i==j) && (j!=k) && (k==m)) {
            
            for(int r = -F; r <= F; r++) {
              
              Ykm+=efC(Ystern[k],Y[m+r]);
              Zkm+=efC(Zstern[k],Z[m+r]);
            }
            
            t+=(KKKK[s]*((Zik+Zki)*(Yik+Yki)+Zij*Ykm+Zkm*Yij)); 
          } else {
            for(int r = -F; r <= F; r++) {
              
              Yim+=efC(Ystern[i],Y[m+r]);
              Zim+=efC(Zstern[i],Z[m+r]);
              Ymi+=efC(Ystern[m],Y[i+r]);
              Zmi+=efC(Zstern[m],Z[i+r]);
              
              Yjm+=efC(Ystern[j],Y[m+r]);
              Zjm+=efC(Zstern[j],Z[m+r]);
              Ymj+=efC(Ystern[m],Y[j+r]);
              Zmj+=efC(Zstern[m],Z[j+r]);
              
              Ykm+=efC(Ystern[k],Y[m+r]);
              Zkm+=efC(Zstern[k],Z[m+r]);
              Ymk+=efC(Ystern[m],Y[k+r]);
              Zmk+=efC(Zstern[m],Z[k+r]);
            }
            t+=(KKKK[s]*((Zjm+Zmj)*(Yik+Yki)+(Zik+Zki)*(Yjm+Ymj)+(Zij+Zji)*(Ykm+Ymk)+(Zkm+Zmk)*(Yij+Yji)+(Zjk+Zkj)*(Yim+Ymi)+(Zim+Zmi)*(Yjk+Ykj)));
          }
          s++;
        }
      }
    }
  }
  return t;
}




// Kern * Kern * Exponentialfunktion Isum1_Estern

// [[Rcpp::export]]
double KVekBS(NumericVector KK, NumericVector Y, NumericVector Z, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j < i; j++) {
      
      for(int r1 = -F; r1 <= F; r1++) {
        
        for(int r2 = -F; r2 <= F; r2++) {
      
          t+=KK[s]*2*efC(Z[i+r1],Z[j+r2])*efC(Y[i+r1],Y[j+r2]);
        }
      }
      s++;
    }
    for(int r1 = -F; r1 <= F; r1++) {
      
      for(int r2 = -F; r2 <= F; r2++) {
        
        t+=(KK[s]*(efC(Z[i+r1],Z[i+r2])*efC(Y[i+r1],Y[i+r2])));
      }
    }
    s++;
  }
  return t;
}



// Kern * Kern * Kern * Exponentialfunktion Isum2_Estern

// [[Rcpp::export]]
double KVekBS2(NumericVector KKK, NumericVector Y, NumericVector Z, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  double Yji;
  double Zji;
  double Yki;
  double Zki;
  double Ykj;
  double Zkj;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        for(int r1 = -F; r1 <= F; r1++) {
          
          for(int r2 = -F; r2 <= F; r2++) {
            
            Yij=efC(Y[i+r1],Y[j+r2]);
            Yik=efC(Y[i+r1],Y[k+r2]);
            Yki=efC(Y[k+r1],Y[i+r2]);
            Yjk=efC(Y[j+r1],Y[k+r2]);
            Yji=efC(Y[j+r1],Y[i+r2]);
            Ykj=efC(Y[k+r1],Y[j+r2]);
            
            for(int r3 = -F; r3 <= F; r3++) {
              
              Zik=efC(Z[i+r1],Z[k+r3]);
              Zjk=efC(Z[j+r1],Z[k+r3]);
              Zji=efC(Z[j+r1],Z[i+r3]);
              Zij=efC(Z[i+r1],Z[j+r3]);
              Zki=efC(Z[k+r1],Z[i+r3]);
              Zkj=efC(Z[k+r1],Z[j+r3]);
              
              if ((i==j) && (j==k)){
                t+=(KKK[s]*(Zij*Yij));
              } else if((i==j) && (j!=k)) {
                t+=(KKK[s]*((Zik*Yij)+(Zki*Yki)+(Zij*Yik)));
              } else if((i!=j) && (j==k)) {
                t+=(KKK[s]*((Zij*Yij)+(Zji*Yjk)+(Zjk*Yji))); 
              } else {
                t+=(KKK[s]*((Zik*Yij)+(Zki*Ykj)+(Zji*Yjk)+(Zij*Yik)+(Zkj*Yki)+(Zjk*Yji)));
              }
            }
          }
        }
        s++;
      }
    }
  }
  return t;
}




// Kern * Kern * Kern * Kern * Exponentialfunktion Isum3_Estern

// [[Rcpp::export]]
double KVekBS3(NumericVector KKKK, NumericVector Y, NumericVector Z, double Anf, double End, int h, int F) {
  int s=0;
  double t=0;
  double Yij;
  double Zij;
  double Yik;
  double Zik;
  double Yjk;
  double Zjk;
  double Yim;
  double Zim;
  double Yjm;
  double Zjm;
  double Ykm;
  double Zkm;
  
  for(double i = Anf; i <= End; i++) {
    
    for(double j = maxC(i-h+1,Anf); j <= i; j++) {
      
      Yij=0;
      Zij=0;
      
      for(int r1 = -F; r1 <= F; r1++) {
        
        for(int r2 = -F; r2 <= F; r2++) {
          
          Yij+=efC(Y[i+r1],Y[j+r2]);
          Zij+=efC(Z[i+r1],Z[j+r2]);
        }
      }
      for(double k = maxC(i-h+1,Anf); k <= j; k++) {
        
        Yik=0;
        Zik=0;
        
        Yjk=0;
        Zjk=0;
        
        for(int r1 = -F; r1 <= F; r1++) {
          
          for(int r2 = -F; r2 <= F; r2++) {
            
            Yik+=efC(Y[i+r1],Y[k+r2]);
            Zik+=efC(Z[i+r1],Z[k+r2]);
            
            Yjk+=efC(Y[j+r1],Y[k+r2]);
            Zjk+=efC(Z[j+r1],Z[k+r2]);
          }
        }
        
        for(double m = maxC(i-h+1,Anf); m <= k; m++) {
          
          Yim=0;
          Zim=0;
          
          Yjm=0;
          Zjm=0;
          
          Ykm=0;
          Zkm=0;
          
          if ((i==j) && (j==k) && (k==m)){
            
            t+=(KKKK[s]*Zij*Yij); 
          } else if ((i==j) && (j==k) && (k!=m)) {
            
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Yim+=efC(Y[i+r1],Y[m+r2]);
                Zim+=efC(Z[i+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*2*((Zim*Yij)+(Zij*Yim))); 
          } else if ((i!=j) && (j==k) && (k==m)) {
            
            t+=(KKKK[s]*2*((Zjk*Yij)+(Zij*Yjk))); 
          } else if ((i==j) && (j!=k) && (k!=m)) {
            
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Yim+=efC(Y[i+r1],Y[m+r2]);
                Zim+=efC(Z[i+r1],Z[m+r2]);
                
                Ykm+=efC(Y[k+r1],Y[m+r2]);
                Zkm+=efC(Z[k+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*((4*((Zim*Yik)+(Zik*Yim)))+(2*((Zij*Ykm)+(Zkm*Yij))))); 
          } else if ((i!=j) && (j!=k) && (k==m)) {
            
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Ykm+=efC(Y[k+r1],Y[m+r2]);
                Zkm+=efC(Z[k+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*((4*((Zjk*Yik)+(Zik*Yjk)))+(2*((Zij*Ykm)+(Zkm*Yij)))));
          } else if ((i!=j) && (j==k) && (k!=m)) {
            
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Yim+=efC(Y[i+r1],Y[m+r2]);
                Zim+=efC(Z[i+r1],Z[m+r2]);
                
                Yjm+=efC(Y[j+r1],Y[m+r2]);
                Zjm+=efC(Z[j+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*((4*((Zjm*Yij)+(Zij*Yjm)))+(2*((Zjk*Yim)+(Zim*Yjk)))));
          } else if ((i==j) && (j!=k) && (k==m)) {
            
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Ykm+=efC(Y[k+r1],Y[m+r2]);
                Zkm+=efC(Z[k+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*((4*Zik*Yik)+Zij*Ykm+Zkm*Yij)); 
          } else {
            for(int r1 = -F; r1 <= F; r1++) {
              
              for(int r2 = -F; r2 <= F; r2++) {
                
                Yim+=efC(Y[i+r1],Y[m+r2]);
                Zim+=efC(Z[i+r1],Z[m+r2]);
                
                Yjm+=efC(Y[j+r1],Y[m+r2]);
                Zjm+=efC(Z[j+r1],Z[m+r2]);
                
                Ykm+=efC(Y[k+r1],Y[m+r2]);
                Zkm+=efC(Z[k+r1],Z[m+r2]);
              }
            }
            
            t+=(KKKK[s]*4*((Zjm*Yik)+(Zik*Yjm)+(Zij*Ykm)+(Zkm*Yij)+(Zjk*Yim)+(Zim*Yjk)));
          }
          s++;
        }
      }
    }
  }
  return t;
}
